 <div class="service-listing-modal-overlay" id="serviceModalOverlay">
    <div class="service-listing-modal-container">
        <!-- Modal Header -->
        <div class="service-listing-modal-header">
            <button type="button" class="service-listing-modal-close-btn" id="closeModalBtn">
                <i class="fas fa-times"></i>
            </button>
            <div class="d-flex align-items-center">
            <div class="me-3">
                <div style="width: 50px; height: 50px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <img src="{{ asset('assets/images/updated-logo.jpeg') }}" style="border-radius: 8px;" height="100%" width="100%" alt="logo">
                </div>
            </div>
            <div>
                <h2 class="service-listing-modal-title">List Your Service</h2>
                <p class="service-listing-modal-subtitle">Join ASKRORO and connect with families in North Texas</p>
            </div>
        </div>
        </div>

        <!-- Step Indicators -->
               

    <!-- Validation Errors Display -->
    @if($errors->any())
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Please fix the following errors:</strong>
        <ul class="mb-0 mt-2">
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    @if(session('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    <!-- Step Indicators -->
    <div class="service-listing-step-indicator-container">
        <div class="service-listing-step-indicator-item service-listing-step-active" data-step="1">
            <div class="service-listing-step-indicator-circle">
                <i class="fas fa-info-circle"></i>
            </div>
            <span class="service-listing-step-indicator-label">Basic Info</span>
        </div>
        <div class="service-listing-step-connector"></div>
        <div class="service-listing-step-indicator-item" data-step="2">
            <div class="service-listing-step-indicator-circle">
                <i class="fas fa-users"></i>
            </div>
            <span class="service-listing-step-indicator-label">Services</span>
        </div>
        <div class="service-listing-step-connector"></div>
        <div class="service-listing-step-indicator-item" data-step="3">
            <div class="service-listing-step-indicator-circle">
                <i class="fas fa-dollar-sign"></i>
            </div>
            <span class="service-listing-step-indicator-label">Pricing</span>
        </div>
        <div class="service-listing-step-connector"></div>
        <div class="service-listing-step-indicator-item" data-step="4">
            <div class="service-listing-step-indicator-circle">
                <i class="fas fa-certificate"></i>
            </div>
            <span class="service-listing-step-indicator-label">Credentials</span>
        </div>
        <div class="service-listing-step-connector"></div>
        <div class="service-listing-step-indicator-item" data-step="5">
            <div class="service-listing-step-indicator-circle">
                <i class="fas fa-camera"></i>
            </div>
            <span class="service-listing-step-indicator-label">Media</span>
        </div>
        <div class="service-listing-step-connector"></div>
        <div class="service-listing-step-indicator-item" data-step="6">
            <div class="service-listing-step-indicator-circle">
                <i class="fas fa-star"></i>
            </div>
            <span class="service-listing-step-indicator-label">Review</span>
        </div>
    </div>

    <!-- Step Form -->
    <form id="serviceListingForm" method="POST" action="{{ route('provider.listings.store') }}" enctype="multipart/form-data">
        @csrf
        
        <!-- Step Content -->
        <div class="service-listing-step-content-area">
            <!-- Step 1: Basic Info -->
            <div class="service-listing-step-content-panel service-listing-step-active-content" id="step1Content">
                <div class="service-listing-step-title-text">
                    <div class="service-listing-step-title-icon">
                        <i class="fas fa-info-circle"></i>
                    </div>
                    Basic Business Information
                </div>
                <p class="service-listing-step-description-text">Tell us about your business and how families can reach you</p>

                <div class="row">
                    <div class="col-12">
                        <div class="service-listing-form-group-container">
                            <label class="service-listing-form-label-text">
                                Profile Name <span class="service-listing-required-field-indicator">*</span>
                            </label>
                            <input type="text" class="service-listing-form-input-field" 
                                   id="profileNameDisplay" value="{{ old('profile_name', auth()->user()->name ?? '') }}" 
                                   placeholder="Cleaner name" disabled>
                            <input type="hidden" id="profileName" name="profile_name" value="{{ old('profile_name', auth()->user()->name ?? '') }}">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="service-listing-form-group-container">
                            <label class="service-listing-form-label-text">
                                Phone Number <span class="service-listing-required-field-indicator">*</span>
                            </label>
                            <input type="tel" class="service-listing-form-input-field @error('phone_number') is-invalid @enderror" 
                                   id="phoneNumber" name="phone_number" 
                                   value="{{ old('phone_number') }}" 
                                   placeholder="(xxx) xxx-xxxx" required>
                            @error('phone_number')
                                <div class="service-listing-error-message-text show">{{ $message }}</div>
                            @else
                                <div class="service-listing-error-message-text">Phone number is required</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="service-listing-form-group-container">
                            <label class="service-listing-form-label-text">
                                Email Address <span class="service-listing-required-field-indicator">*</span>
                            </label>
                            <input type="email" class="service-listing-form-input-field @error('email') is-invalid @enderror" 
                                   id="emailAddress" name="email" 
                                   value="{{ old('email') }}" 
                                   placeholder="your@email.com" required>
                            @error('email')
                                <div class="service-listing-error-message-text show">{{ $message }}</div>
                            @else
                                <div class="service-listing-error-message-text">Valid email address is required</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="service-listing-form-group-container">
                            <label class="service-listing-form-label-text">
                                Physical Address <span class="service-listing-required-field-indicator">*</span>
                            </label>
                            <input type="text" class="service-listing-form-input-field @error('physical_address') is-invalid @enderror" 
                                   id="physicalAddress" name="physical_address" 
                                   value="{{ old('physical_address') }}" 
                                   placeholder="Street Address" required>
                            @error('physical_address')
                                <div class="service-listing-error-message-text show">{{ $message }}</div>
                            @else
                                <div class="service-listing-error-message-text">Valid physical address is required</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="service-listing-form-group-container">
                            <label class="service-listing-form-label-text">
                                City <span class="service-listing-required-field-indicator">*</span>
                            </label>
                            <input type="text" class="service-listing-form-input-field @error('city') is-invalid @enderror" 
                                   id="cityinfo" name="city" 
                                   value="{{ old('city') }}" 
                                   placeholder="City" required>
                            @error('city')
                                <div class="service-listing-error-message-text show">{{ $message }}</div>
                            @else
                                <div class="service-listing-error-message-text">Valid city is required</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="service-listing-form-group-container">
                            <label class="service-listing-form-label-text">State</label>
                            <select class="service-listing-form-input-field @error('state') is-invalid @enderror" name="state" id="state">
                                <option value="TX" {{ old('state', 'TX') == 'TX' ? 'selected' : '' }}>TX</option>
                            </select>
                            @error('state')
                                <div class="service-listing-error-message-text show">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="service-listing-form-group-container">
                            <label class="service-listing-form-label-text">
                                ZIP Code <span class="service-listing-required-field-indicator">*</span>
                            </label>
                            <input type="text" class="service-listing-form-input-field @error('zip_code') is-invalid @enderror" 
                                   id="zipCode" name="zip_code" 
                                   value="{{ old('zip_code') }}" 
                                   maxlength="5" minlength="5" placeholder="75XXX" required>
                            @error('zip_code')
                                <div class="service-listing-error-message-text show">{{ $message }}</div>
                            @else
                                <div class="service-listing-error-message-text">Valid ZIP code is required</div>
                            @enderror
                        </div>
                    </div>
                </div>
            </div>

            <!-- Step 2: Services -->
            <div class="service-listing-step-content-panel" id="step2Content" style="display: none;">
                <div class="service-listing-step-title-text">
                    <div class="service-listing-step-title-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    Services You Provide
                </div>
                <p class="service-listing-step-description-text">Select all the services you offer to families</p>

                <div class="service-listing-form-group-container">
                    <label class="service-listing-form-label-text">
                        Service Categories <span class="service-listing-required-field-indicator">*</span>
                    </label>
                    <div class="service-listing-checkbox-group-container">
                        @php
                            $oldServices = old('service_categories', []);
                        @endphp
                        @foreach(\App\Models\Category::whereNull('parent_id')->get() as $category)
                        <div class="service-listing-checkbox-item-wrapper" data-service="{{ $category->name }}">
                            <input type="checkbox" id="service-{{ $category->slug }}" name="service_categories[]" value="{{ $category->name }}" 
                                   class="service-listing-service-checkbox form-check-input mt-0 @error('service_categories') is-invalid @enderror"
                                   {{ in_array($category->name, $oldServices) ? 'checked' : '' }}>
                            <label for="service-{{ $category->slug }}">{{ $category->name }}</label>
                        </div>
                        @endforeach
                    </div>
                    @error('service_categories')
                        <div class="service-listing-error-message-text show">{{ $message }}</div>
                    @else
                        <div class="service-listing-error-message-text">Please select at least one service</div>
                    @enderror
                </div>

                <div class="service-listing-form-group-container">
                    <label class="service-listing-form-label-text">Service Description</label>
                    <textarea class="service-listing-form-textarea-field @error('service_description') is-invalid @enderror" 
                              id="serviceDescription" name="service_description" rows="4" 
                              placeholder="Describe your services in detail...">{{ old('service_description') }}</textarea>
                    @error('service_description')
                        <div class="service-listing-error-message-text show">{{ $message }}</div>
                    @enderror
                </div>
            </div>

            <!-- Step 3: Pricing & Schedule -->
            <div class="service-listing-step-content-panel" id="step3Content" style="display: none;">
                <div class="service-listing-step-title-text">
                    <div class="service-listing-step-title-icon">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    Pricing & Schedule
                </div>
                
                <!-- Pricing Options Section -->
                <div class="pricing-section">
                    <h4 class="service-listing-form-label-text">Pricing Options</h4>
                    <p class="service-listing-step-description-text">Select how you'd like to structure your pricing:</p>
                    
                    <div class="pricing-options">
                        <div class="pricing-option @if(old('pricing_type', 'package') == 'hourly') selected @endif" data-type="hourly">
                            <div class="pricing-option-name">Hourly Rate</div>
                            <div class="pricing-option-price">$<span>25</span></div>
                            <ul class="pricing-option-features">
                                <li>Charge by the hour</li>
                                <li>Flexible scheduling</li>
                                <li>Best for variable services</li>
                            </ul>
                        </div>
                        
                        <div class="pricing-option @if(old('pricing_type', 'package') == 'fixed') selected @endif" data-type="fixed">
                            <div class="pricing-option-name">Fixed Price</div>
                            <div class="pricing-option-price">$<span>150</span></div>
                            <ul class="pricing-option-features">
                                <li>Flat fee per session</li>
                                <li>Clear pricing for clients</li>
                                <li>Great for standard packages</li>
                            </ul>
                        </div>
                        
                        <div class="pricing-option @if(old('pricing_type', 'package') == 'package') selected @endif" data-type="package">
                            <div class="pricing-option-name">Package Deal</div>
                            <div class="pricing-option-price">$<span>500</span></div>
                            <ul class="pricing-option-features">
                                <li>Multiple sessions bundled</li>
                                <li>Discount for commitment</li>
                                <li>Encourages long-term engagement</li>
                            </ul>
                        </div>
                        
                        <div class="pricing-option @if(old('pricing_type', 'package') == 'custom') selected @endif" data-type="custom">
                            <div class="pricing-option-name">Custom Pricing</div>
                            <div class="pricing-option-price">$<span>0</span></div>
                            <ul class="pricing-option-features">
                                <li>Set your own terms</li>
                                <li>Negotiate with clients</li>
                                <li>Perfect for unique services</li>
                            </ul>
                        </div>
                    </div>
                    
                    <input type="hidden" name="pricing_type" id="pricingType" value="{{ old('pricing_type', 'package') }}">
                    
                    <div class="service-listing-form-group-container mt-4">
                        <label class="service-listing-form-label-text">Price Amount <span class="service-listing-required-field-indicator">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text">$</span>
                            <input type="number" class="service-listing-form-input-field @error('price_amount') is-invalid @enderror" 
                                   id="price-amount" name="price_amount" 
                                   value="{{ old('price_amount') }}" 
                                   placeholder="Enter price amount" min="0" step="1" required>
                        </div>
                        @error('price_amount')
                            <div class="service-listing-error-message-text show">{{ $message }}</div>
                        @else
                            <small class="form-text text-muted">Enter the specific price amount based on your selected pricing type</small>
                        @enderror
                    </div>
                    
                    <div class="service-listing-form-group-container">
                        <label class="service-listing-form-label-text">Pricing Description</label>
                        <textarea class="service-listing-form-textarea-field @error('pricing_description') is-invalid @enderror" 
                                  id="pricing-description" name="pricing_description" rows="3" 
                                  placeholder="Describe your pricing structure, any discounts, payment methods, cancellation policy, etc.">{{ old('pricing_description') }}</textarea>
                        @error('pricing_description')
                            <div class="service-listing-error-message-text show">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <!-- Schedule Section -->
                <div class="service-listing-form-group-container mt-4">
                    <label class="service-listing-form-label-text">Hours of Operation / Schedules</label>
                    <div class="row">
                        <div class="col-md-6">
                            <label class="service-listing-form-label-text">Available Days</label>
                            <div class="service-listing-checkbox-group-container">
                                @php
                                    $oldDays = old('available_days', []);
                                @endphp
                                <div><input type="checkbox" name="available_days[]" value="monday" 
                                           class="form-check-input me-2 @error('available_days') is-invalid @enderror"
                                           {{ in_array('monday', $oldDays) ? 'checked' : '' }}><label> Monday</label></div>
                                <div><input type="checkbox" name="available_days[]" value="tuesday" 
                                           class="form-check-input me-2 @error('available_days') is-invalid @enderror"
                                           {{ in_array('tuesday', $oldDays) ? 'checked' : '' }}><label> Tuesday</label></div>
                                <div><input type="checkbox" name="available_days[]" value="wednesday" 
                                           class="form-check-input me-2 @error('available_days') is-invalid @enderror"
                                           {{ in_array('wednesday', $oldDays) ? 'checked' : '' }}><label> Wednesday</label></div>
                                <div><input type="checkbox" name="available_days[]" value="thursday" 
                                           class="form-check-input me-2 @error('available_days') is-invalid @enderror"
                                           {{ in_array('thursday', $oldDays) ? 'checked' : '' }}><label> Thursday</label></div>
                                <div><input type="checkbox" name="available_days[]" value="friday" 
                                           class="form-check-input me-2 @error('available_days') is-invalid @enderror"
                                           {{ in_array('friday', $oldDays) ? 'checked' : '' }}><label> Friday</label></div>
                                <div><input type="checkbox" name="available_days[]" value="saturday" 
                                           class="form-check-input me-2 @error('available_days') is-invalid @enderror"
                                           {{ in_array('saturday', $oldDays) ? 'checked' : '' }}><label> Saturday</label></div>
                                <div><input type="checkbox" name="available_days[]" value="sunday" 
                                           class="form-check-input me-2 @error('available_days') is-invalid @enderror"
                                           {{ in_array('sunday', $oldDays) ? 'checked' : '' }}><label> Sunday</label></div>
                            </div>
                            @error('available_days')
                                <div class="service-listing-error-message-text show">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-6">
                            <label class="service-listing-form-label-text">Working Hours</label>
                            <div class="d-flex gap-2 align-items-center">
                                <input type="time" class="service-listing-form-input-field @error('start_time') is-invalid @enderror" 
                                       id="start-time" name="start_time" 
                                       value="{{ old('start_time') }}" 
                                       placeholder="Start time">
                                <span>to</span>
                                <input type="time" class="service-listing-form-input-field @error('end_time') is-invalid @enderror" 
                                       id="end-time" name="end_time" 
                                       value="{{ old('end_time') }}" 
                                       placeholder="End time">
                            </div>
                            @error('start_time')
                                <div class="service-listing-error-message-text show">{{ $message }}</div>
                            @enderror
                            @error('end_time')
                                <div class="service-listing-error-message-text show">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>
                
                <div class="service-listing-form-group-container">
                    <label class="service-listing-form-label-text">Additional Availability Notes</label>
                    <textarea class="service-listing-form-textarea-field @error('availability_notes') is-invalid @enderror" 
                              id="availability-notes" name="availability_notes" rows="2" 
                              placeholder="Any special availability? (e.g., weekends only, holidays, flexible hours)">{{ old('availability_notes') }}</textarea>
                    @error('availability_notes')
                        <div class="service-listing-error-message-text show">{{ $message }}</div>
                    @enderror
                </div>
            </div>

            <!-- Step 4: Credentials removed per product decision -->
            <div class="service-listing-step-content-panel" id="step4Content" style="display: none;">
                <div class="service-listing-step-title-text">
                    <div class="service-listing-step-title-icon">
                        <i class="fas fa-certificate"></i>
                    </div>
                    Credentials
                </div>
                <p class="service-listing-step-description-text">(Credentials section has been simplified)</p>

                <div class="service-listing-form-group-container">
                    <label class="service-listing-form-label-text">Special Features</label>
                    <div class="service-listing-checkbox-group-container">
                        @php
                            $oldFeatures = old('special_features', []);
                        @endphp
                        <div><input type="checkbox" class="form-check-input me-2 @error('special_features') is-invalid @enderror" 
                                   id="feature-stem" name="special_features[]" value="stem"
                                   {{ in_array('stem', $oldFeatures) ? 'checked' : '' }}><label for="feature-stem"> STEM Focus</label></div>
                        <div><input type="checkbox" class="form-check-input me-2 @error('special_features') is-invalid @enderror" 
                                   id="feature-arts" name="special_features[]" value="arts"
                                   {{ in_array('arts', $oldFeatures) ? 'checked' : '' }}><label for="feature-arts"> Arts & Music</label></div>
                        <div><input type="checkbox" class="form-check-input me-2 @error('special_features') is-invalid @enderror" 
                                   id="feature-special" name="special_features[]" value="special"
                                   {{ in_array('special', $oldFeatures) ? 'checked' : '' }}><label for="feature-special"> Special Needs Support</label></div>
                        <div><input type="checkbox" class="form-check-input me-2 @error('special_features') is-invalid @enderror" 
                                   id="feature-outdoor" name="special_features[]" value="outdoor"
                                   {{ in_array('outdoor', $oldFeatures) ? 'checked' : '' }}><label for="feature-outdoor"> Outdoor Activities</label></div>
                        <div><input type="checkbox" class="form-check-input me-2 @error('special_features') is-invalid @enderror" 
                                   id="feature-language" name="special_features[]" value="language"
                                   {{ in_array('language', $oldFeatures) ? 'checked' : '' }}><label for="feature-language"> Language Immersion</label></div>
                        <div><input type="checkbox" class="form-check-input me-2 @error('special_features') is-invalid @enderror" 
                                   id="feature-sports" name="special_features[]" value="sports"
                                   {{ in_array('sports', $oldFeatures) ? 'checked' : '' }}><label for="feature-sports"> Sports Programs</label></div>
                        <div><input type="checkbox" class="form-check-input me-2 @error('special_features') is-invalid @enderror" 
                                   id="feature-organic" name="special_features[]" value="organic"
                                   {{ in_array('organic', $oldFeatures) ? 'checked' : '' }}><label for="feature-organic"> Organic/Healthy Meals</label></div>
                        <div><input type="checkbox" class="form-check-input me-2 @error('special_features') is-invalid @enderror" 
                                   id="feature-technology" name="special_features[]" value="technology"
                                   {{ in_array('technology', $oldFeatures) ? 'checked' : '' }}><label for="feature-technology"> Technology Integration</label></div>
                    </div>
                    @error('special_features')
                        <div class="service-listing-error-message-text show">{{ $message }}</div>
                    @enderror
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="service-listing-form-group-container">
                            <label class="service-listing-form-label-text">Website</label>
                            <input type="url" class="service-listing-form-input-field @error('website') is-invalid @enderror" 
                                   id="website" name="website" 
                                   value="{{ old('website') }}" 
                                   placeholder="https://www.yourwebsite.com">
                            @error('website')
                                <div class="service-listing-error-message-text show">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="service-listing-form-group-container">
                            <label class="service-listing-form-label-text">Facebook Page</label>
                            <input type="url" class="service-listing-form-input-field @error('facebook') is-invalid @enderror" 
                                   id="facebook" name="facebook" 
                                   value="{{ old('facebook') }}" 
                                   placeholder="Facebook page URL">
                            @error('facebook')
                                <div class="service-listing-error-message-text show">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="service-listing-form-group-container">
                            <label class="service-listing-form-label-text">Instagram</label>
                            <input type="url" class="service-listing-form-input-field @error('instagram') is-invalid @enderror" 
                                   id="instagram" name="instagram" 
                                   value="{{ old('instagram') }}" 
                                   placeholder="Instagram profile URL">
                            @error('instagram')
                                <div class="service-listing-error-message-text show">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>
            </div>

            <!-- Step 5: Media -->
            <div class="service-listing-step-content-panel" id="step5Content" style="display: none;">
                <div class="service-listing-step-title-text">
                    <div class="service-listing-step-title-icon">
                        <i class="fas fa-camera"></i>
                    </div>
                    Media & Photos
                </div>
                
                <h6 class="mt-3">Business Logo</h6>
                <div class="service-listing-form-group-container">
                    <label class="service-listing-form-label-text">Upload your business logo (recommended: square format, 500x500px minimum)</label>
                    <div class="service-listing-file-upload-area @error('logo') is-invalid @enderror" id="logoUploadArea">
                        <div class="service-listing-upload-icon">
                            <i class="fas fa-cloud-upload-alt"></i>
                        </div>
                        <div class="service-listing-upload-text">
                            <strong>Drag & drop files here</strong><br>
                            or click to browse<br>
                            <small>Supports JPG, PNG files up to 10MB</small>
                        </div>
                        <input type="file" id="logo" name="logo" accept="image/*" style="display: none;">
                    </div>
                    @error('logo')
                        <div class="service-listing-error-message-text show">{{ $message }}</div>
                    @enderror
                    <div class="service-listing-uploaded-files-list" id="logoFilesList"></div>
                </div>

                <h6>Facility Photos</h6>
                <div class="service-listing-form-group-container">
                    <label class="service-listing-form-label-text">Share photos of your space, activities, and services (up to 10 photos)</label>
                    <div class="service-listing-file-upload-area @error('facility_photos') is-invalid @enderror" id="facilityPhotosUploadArea">
                        <div class="service-listing-upload-icon">
                            <i class="fas fa-cloud-upload-alt"></i>
                        </div>
                        <div class="service-listing-upload-text">
                            <strong>Drag & drop files here</strong><br>
                            or click to browse<br>
                            <small>Supports JPG, PNG files up to 10MB</small>
                        </div>
                        <input type="file" id="facility_photos" name="facility_photos[]" multiple accept="image/*" style="display: none;">
                    </div>
                    @error('facility_photos')
                        <div class="service-listing-error-message-text show">{{ $message }}</div>
                    @enderror
                    @error('facility_photos.*')
                        <div class="service-listing-error-message-text show">{{ $message }}</div>
                    @enderror
                    <div class="service-listing-uploaded-files-list" id="facilityPhotosList"></div>
                </div>

                <h6>License Documentation</h6>
                <div class="service-listing-form-group-container">
                    <label class="service-listing-form-label-text">Upload copies of your licenses and certifications (optional but recommended)</label>
                    <div class="service-listing-file-upload-area @error('license_docs') is-invalid @enderror" id="licenseDocsUploadArea">
                        <div class="service-listing-upload-icon">
                            <i class="fas fa-cloud-upload-alt"></i>
                        </div>
                        <div class="service-listing-upload-text">
                            <strong>Drag & drop files here</strong><br>
                            or click to browse<br>
                            <small>Supports JPG, PNG, PDF files up to 10MB</small>
                        </div>
                        <input type="file" id="license_docs" name="license_docs[]" multiple accept="image/*,.pdf" style="display: none;">
                    </div>
                    @error('license_docs')
                        <div class="service-listing-error-message-text show">{{ $message }}</div>
                    @enderror
                    @error('license_docs.*')
                        <div class="service-listing-error-message-text show">{{ $message }}</div>
                    @enderror
                    <div class="service-listing-uploaded-files-list" id="licenseDocsList"></div>
                </div>
            </div>

            <!-- Step 6: Review -->
            <div class="service-listing-step-content-panel" id="step6Content" style="display: none;">
                <div class="service-listing-step-title-text">
                    <div class="service-listing-step-title-icon">
                        <i class="fas fa-star"></i>
                    </div>
                    Review & Submit
                </div>
                <p class="service-listing-step-description-text">Please review all information before submitting your service listing</p>

                <div class="service-listing-review-section-container">
                    <h4 class="service-listing-review-section-title">
                        <i class="fas fa-info-circle text-primary me-2"></i>Basic Information
                    </h4>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Profile Name:</span>
                        <span class="service-listing-review-field-value" id="reviewBusinessName">-</span>
                    </div>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Phone:</span>
                        <span class="service-listing-review-field-value" id="reviewPhone">-</span>
                    </div>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Email:</span>
                        <span class="service-listing-review-field-value" id="reviewEmail">-</span>
                    </div>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Address:</span>
                        <span class="service-listing-review-field-value" id="reviewAddress">-</span>
                    </div>
                </div>

                <div class="service-listing-review-section-container">
                    <h4 class="service-listing-review-section-title">
                        <i class="fas fa-users text-success me-2"></i>Services
                    </h4>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Selected Services:</span>
                        <span class="service-listing-review-field-value" id="reviewServices">-</span>
                    </div>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Description:</span>
                        <span class="service-listing-review-field-value" id="reviewDescription">-</span>
                    </div>
                </div>

                <div class="service-listing-review-section-container">
                    <h4 class="service-listing-review-section-title">
                        <i class="fas fa-dollar-sign text-warning me-2"></i>Pricing & Schedule
                    </h4>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Pricing Type:</span>
                        <span class="service-listing-review-field-value" id="reviewPricingType">-</span>
                    </div>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Price Amount:</span>
                        <span class="service-listing-review-field-value" id="reviewPriceAmount">-</span>
                    </div>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Available Days:</span>
                        <span class="service-listing-review-field-value" id="reviewAvailableDays">-</span>
                    </div>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Working Hours:</span>
                        <span class="service-listing-review-field-value" id="reviewWorkingHours">-</span>
                    </div>
                </div>

                <div class="service-listing-review-section-container">
                    <h4 class="service-listing-review-section-title">
                        <i class="fas fa-certificate text-warning me-2"></i>Credentials
                    </h4>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">License Number:</span>
                        <span class="service-listing-review-field-value" id="reviewLicenseNumber">-</span>
                    </div>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Years in Operation:</span>
                        <span class="service-listing-review-field-value" id="reviewYearsOperation">-</span>
                    </div>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Insurance Coverage:</span>
                        <span class="service-listing-review-field-value" id="reviewInsurance">-</span>
                    </div>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Diversity Badges:</span>
                        <span class="service-listing-review-field-value" id="reviewDiversityBadges">-</span>
                    </div>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Special Features:</span>
                        <span class="service-listing-review-field-value" id="reviewSpecialFeatures">-</span>
                    </div>
                </div>

                <div class="service-listing-review-section-container">
                    <h4 class="service-listing-review-section-title">
                        <i class="fas fa-camera text-info me-2"></i>Media & Links
                    </h4>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Website:</span>
                        <span class="service-listing-review-field-value" id="reviewWebsite">-</span>
                    </div>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Facebook:</span>
                        <span class="service-listing-review-field-value" id="reviewFacebook">-</span>
                    </div>
                    <div class="service-listing-review-field-row">
                        <span class="service-listing-review-field-label">Instagram:</span>
                        <span class="service-listing-review-field-value" id="reviewInstagram">-</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal Footer -->
        <div class="service-listing-modal-footer-actions">
            <button type="button" class="service-listing-navigation-button service-listing-prev-button" id="prevStepBtn" disabled>
                <i class="fas fa-arrow-left me-2"></i>Previous
            </button>
            <button type="button" class="service-listing-navigation-button service-listing-next-button" id="nextStepBtn">
                Next<i class="fas fa-arrow-right ms-2"></i>
            </button>
            <button type="submit" class="service-listing-navigation-button service-listing-submit-button" id="submitFormBtn" style="display: none;">
                <i class="fas fa-paper-plane me-2"></i>Submit Listing
            </button>
        </div>
    </form>
    </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', function() {


    let currentStep = 1;
    const totalSteps = 6;
    
    // Navigation elements
    const prevBtn = document.getElementById('prevStepBtn');
    const nextBtn = document.getElementById('nextStepBtn');
    const submitBtn = document.getElementById('submitFormBtn');
    
    // Step content panels
    const stepPanels = document.querySelectorAll('.service-listing-step-content-panel');
    
    // Step indicators
    const stepIndicators = document.querySelectorAll('.service-listing-step-indicator-item');
    const stepConnectors = document.querySelectorAll('.service-listing-step-connector');
    
    // Pricing options functionality
    const pricingOptions = document.querySelectorAll('.pricing-option');
    const pricingTypeInput = document.getElementById('pricingType');
    let selectedPricingType = '{{ old('pricing_type', 'package') }}'; // Use old value or default
    
    // Check if there are validation errors and jump to the first step with errors
    const hasErrors = document.querySelector('.alert-danger') !== null;
    if (hasErrors) {
        // Find the first step that has errors
        const errorSteps = new Set();
        document.querySelectorAll('.is-invalid').forEach(element => {
            const stepPanel = element.closest('.service-listing-step-content-panel');
            if (stepPanel) {
                const stepId = stepPanel.id;
                const stepNumber = stepId.replace('step', '').replace('Content', '');
                errorSteps.add(parseInt(stepNumber));
            }
        });
        
        if (errorSteps.size > 0) {
            const firstErrorStep = Math.min(...Array.from(errorSteps));
            currentStep = firstErrorStep;
        }
    }
    
    // Initialize pricing options
    pricingOptions.forEach(option => {
        if (option.dataset.type === selectedPricingType) {
            option.classList.add('selected');
        }
        
            option.addEventListener('click', function() {
            // Remove selected class from all options
            pricingOptions.forEach(opt => opt.classList.remove('selected'));
            // Add selected class to clicked option
            this.classList.add('selected');
            // Update selected pricing type
            selectedPricingType = this.dataset.type;
            pricingTypeInput.value = selectedPricingType;
            // Pricing is managed externally; cleaners do not set price here.
        });
    });
    
    // Update navigation buttons
    function updateNavigation() {
        // Previous button
        prevBtn.disabled = currentStep === 1;
        
        // Next/Submit button
        if (currentStep === totalSteps) {
            nextBtn.style.display = 'none';
            submitBtn.style.display = 'block';
            updateReviewData();
        } else {
            nextBtn.style.display = 'block';
            submitBtn.style.display = 'none';
        }
        
        // Update step indicators
        stepIndicators.forEach((indicator, index) => {
            const stepNumber = index + 1;
            if (stepNumber < currentStep) {
                indicator.classList.add('service-listing-step-completed');
                indicator.classList.remove('service-listing-step-active');
            } else if (stepNumber === currentStep) {
                indicator.classList.add('service-listing-step-active');
                indicator.classList.remove('service-listing-step-completed');
            } else {
                indicator.classList.remove('service-listing-step-active', 'service-listing-step-completed');
            }
        });
        
        // Update step connectors
        stepConnectors.forEach((connector, index) => {
            if (index + 1 < currentStep) {
                connector.classList.add('service-listing-step-connector-active');
            } else {
                connector.classList.remove('service-listing-step-connector-active');
            }
        });
    }
    
    // Show current step content
    function showStep(stepNumber) {
        stepPanels.forEach(panel => {
            panel.style.display = 'none';
        });
        
        const currentStepPanel = document.getElementById(`step${stepNumber}Content`);
        if (currentStepPanel) {
            currentStepPanel.style.display = 'block';
            
            // Scroll to top of the form
            currentStepPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
    
    // Validate current step
    function validateStep(step) {
        let isValid = true;
        const errorFields = [];

              errorFields.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field) {
                field.classList.remove('is-invalid');
            }
        });
        
                switch(step) {
            case 1:
                // Validate basic info
                const profileName = document.getElementById('profileName');
                const phoneNumber = document.getElementById('phoneNumber');
                const emailAddress = document.getElementById('emailAddress');
                const physicalAddress = document.getElementById('physicalAddress');
                const cityinfo = document.getElementById('cityinfo');
                const zipCode = document.getElementById('zipCode');
                console.log(errorFields)
                
                if (!profileName || !profileName.value.trim()) {
                    isValid = false;
                    errorFields.push('profileName');
                }
                if (!phoneNumber.value.trim()) {
                    isValid = false;
                    errorFields.push('phoneNumber');
                }
                if (!emailAddress.value.trim() || !isValidEmail(emailAddress.value)) {
                    isValid = false;
                    errorFields.push('emailAddress');
                }
                if (!physicalAddress.value.trim()) {
                    isValid = false;
                    errorFields.push('physicalAddress');
                }
                if (!cityinfo.value.trim()) {
                    isValid = false;
                    errorFields.push('cityinfo');
                }
                if (!zipCode.value.trim() || zipCode.value.length !== 5) {
                    isValid = false;
                    errorFields.push('zipCode');
                }
                break;
                
            case 2:
                // Validate services
                const serviceCheckboxes = document.querySelectorAll('input[name="sub_categories[]"]:checked');
                if (serviceCheckboxes.length === 0) {
                    isValid = false;
                    // Highlight service categories container
                    const serviceContainer = document.querySelector('.service-listing-checkbox-group-container');
                    serviceContainer.classList.add('border', 'border-danger', 'rounded', 'p-2');
                } else {
                    const serviceContainer = document.querySelector('.service-listing-checkbox-group-container');
                    serviceContainer.classList.remove('border', 'border-danger', 'rounded', 'p-2');
                }
                break;
                
            case 3:
                // Pricing step removed from validation here; pricing is set externally.
                break;
                
            // Add validation for other steps as needed
        }
        
        // Highlight error fields
        errorFields.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field) {
                field.classList.add('is-invalid');
            }
        });
        
        return isValid;
    }
    
    // Email validation helper
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    // Update review data
    function updateReviewData() {
        // Basic Info
        document.getElementById('reviewBusinessName').textContent = (document.getElementById('profileName') && document.getElementById('profileName').value) ? document.getElementById('profileName').value : '-';
        document.getElementById('reviewPhone').textContent = document.getElementById('phoneNumber').value || '-';
        document.getElementById('reviewEmail').textContent = document.getElementById('emailAddress').value || '-';
        
        const address = [
            document.getElementById('physicalAddress').value,
            document.getElementById('cityinfo').value,
            document.getElementById('state').value,
            document.getElementById('zipCode').value
        ].filter(Boolean).join(', ');
        document.getElementById('reviewAddress').textContent = address || '-';
        
        // Services
        const selectedServices = Array.from(document.querySelectorAll('input[name="sub_categories[]"]:checked'))
            .map(cb => cb.nextElementSibling.textContent).join(', ');
        document.getElementById('reviewServices').textContent = selectedServices || '-';
        document.getElementById('reviewDescription').textContent = document.getElementById('serviceDescription').value || '-';
        
        // Pricing & Schedule
        document.getElementById('reviewPricingType').textContent = selectedPricingType.charAt(0).toUpperCase() + selectedPricingType.slice(1);
        document.getElementById('reviewPriceAmount').textContent = 'Pricing available on request';
        
        const availableDays = Array.from(document.querySelectorAll('input[name="available_days[]"]:checked'))
            .map(cb => cb.value.charAt(0).toUpperCase() + cb.value.slice(1)).join(', ');
        document.getElementById('reviewAvailableDays').textContent = availableDays || '-';
        
        const startTime = document.getElementById('start-time').value;
        const endTime = document.getElementById('end-time').value;
        document.getElementById('reviewWorkingHours').textContent = (startTime && endTime) ? `${startTime} to ${endTime}` : '-';
        
        // Credentials removed — do not display license/years/insurance/diversity in review
        document.getElementById('reviewLicenseNumber') && (document.getElementById('reviewLicenseNumber').textContent = '-');
        document.getElementById('reviewYearsOperation') && (document.getElementById('reviewYearsOperation').textContent = '-');
        document.getElementById('reviewInsurance') && (document.getElementById('reviewInsurance').textContent = '-');
        document.getElementById('reviewDiversityBadges') && (document.getElementById('reviewDiversityBadges').textContent = '-');
        
        const specialFeatures = Array.from(document.querySelectorAll('input[name="special_features[]"]:checked'))
            .map(cb => cb.nextElementSibling.textContent.trim()).join(', ');
        document.getElementById('reviewSpecialFeatures').textContent = specialFeatures || '-';
        
        // Media & Links
        document.getElementById('reviewWebsite').textContent = document.getElementById('website').value || '-';
        document.getElementById('reviewFacebook').textContent = document.getElementById('facebook').value || '-';
        document.getElementById('reviewInstagram').textContent = document.getElementById('instagram').value || '-';
    }
    
    // Event listeners
    nextBtn.addEventListener('click', function() {
        if (validateStep(currentStep)) {
            currentStep++;
            showStep(currentStep);
            updateNavigation();
        } else {
            
            // Scroll to first error field
            const firstErrorField = document.querySelector('.is-invalid');
            if (firstErrorField) {
                firstErrorField.scrollIntoView({ behavior: 'smooth', block: 'center' });
                firstErrorField.focus();
            }
        }
    });
    
    prevBtn.addEventListener('click', function() {
        if (currentStep > 1) {
            currentStep--;
            showStep(currentStep);
            updateNavigation();
        }
    });
    
    // File upload functionality
    const uploadAreas = document.querySelectorAll('.service-listing-file-upload-area');
    uploadAreas.forEach(area => {
        const fileInput = area.querySelector('input[type="file"]');
        const filesList = area.nextElementSibling.nextElementSibling; // Skip error message div
        
        area.addEventListener('click', function() {
            fileInput.click();
        });
        
        area.addEventListener('dragover', function(e) {
            e.preventDefault();
            area.style.backgroundColor = 'rgba(0, 123, 255, 0.1)';
        });
        
        area.addEventListener('dragleave', function() {
            area.style.backgroundColor = '';
        });
        
        area.addEventListener('drop', function(e) {
            e.preventDefault();
            area.style.backgroundColor = '';
            if (e.dataTransfer.files.length > 0) {
                fileInput.files = e.dataTransfer.files;
                updateFileList(fileInput, filesList);
            }
        });
        
        fileInput.addEventListener('change', function() {
            updateFileList(fileInput, filesList);
        });
    });
    
    function updateFileList(fileInput, filesList) {
        filesList.innerHTML = '';
        if (fileInput.files.length > 0) {
            Array.from(fileInput.files).forEach(file => {
                const fileItem = document.createElement('div');
                fileItem.className = 'service-listing-uploaded-file-item';
                fileItem.innerHTML = `
                    <i class="fas fa-file me-2"></i>
                    <span>${file.name}</span>
                    <small>(${(file.size / 1024 / 1024).toFixed(2)} MB)</small>
                `;
                filesList.appendChild(fileItem);
            });
        }
    }
    
    // Real-time validation for email
    const emailField = document.getElementById('emailAddress');
    if (emailField) {
        emailField.addEventListener('blur', function() {
            if (this.value && !isValidEmail(this.value)) {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    }
    
    // Real-time validation for ZIP code
    const zipField = document.getElementById('zipCode');
    if (zipField) {
        zipField.addEventListener('blur', function() {
            if (this.value && this.value.length !== 5) {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    }
    
    // Initialize
    showStep(currentStep);
    updateNavigation();
});
</script>

<style>
.service-listing-step-content-panel {
    transition: all 0.3s ease;
}

.service-listing-step-indicator-item.service-listing-step-completed .service-listing-step-indicator-circle {
    background-color: #28a745;
    color: white;
}

.service-listing-step-connector.service-listing-step-connector-active {
    background-color: #28a745;
}

.service-listing-uploaded-file-item {
    padding: 8px 12px;
    background: #f8f9fa;
    border-radius: 4px;
    margin: 5px 0;
    border: 1px solid #dee2e6;
}

.service-listing-submit-button {
    background-color: #28a745;
    border-color: #28a745;
    color: white;
}

.service-listing-submit-button:hover {
    background-color: #218838;
    border-color: #1e7e34;
}

/* Pricing Options Styles */
.pricing-options {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1rem;
    margin: 1rem 0;
}

.pricing-option {
    border: 2px solid #e9ecef;
    border-radius: 8px;
    padding: 1.5rem;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
    background: white;
}

.pricing-option:hover {
    border-color: #007bff;
    transform: translateY(-2px);
}

.pricing-option.selected {
    border-color: #007bff;
    background-color: #f8f9fa;
    box-shadow: 0 4px 8px rgba(0, 123, 255, 0.2);
}

.pricing-option-name {
    font-weight: bold;
    font-size: 1.1rem;
    margin-bottom: 0.5rem;
    color: #333;
}

.pricing-option-price {
    font-size: 1.5rem;
    font-weight: bold;
    color: #007bff;
    margin-bottom: 1rem;
}

.pricing-option-features {
    list-style: none;
    padding: 0;
    margin: 0;
    text-align: left;
}

.pricing-option-features li {
    padding: 0.25rem 0;
    font-size: 0.9rem;
    color: #666;
}

.pricing-option-features li:before {
    content: "✓";
    color: #28a745;
    font-weight: bold;
    margin-right: 0.5rem;
}

.input-group-text {
    background-color: #f8f9fa;
    border: 1px solid #ced4da;
}

/* Error styling */
.is-invalid {
    border-color: #dc3545 !important;
}

.service-listing-error-message-text {
    display: none;
    color: #dc3545;
    font-size: 0.875rem;
    margin-top: 0.25rem;
}

.service-listing-error-message-text.show {
    display: block;
}

.alert-danger {
    border-left: 4px solid #dc3545;
}

.alert-success {
    border-left: 4px solid #28a745;
}
</style>
